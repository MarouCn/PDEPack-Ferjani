# PDEPack
Das Git-Repo mit den Musterlösungen für die Praktikumsaufgaben.

Einige Zeit nach der Bearbeitung der verschiedenen Blätter, die zur Prüfungsleistung hinführen finden Sie hier die Quelltexte der Musterlösungen.
Die einzelnen Blätter werden dabei entweder über einen Tag oder einen Branch gekennzeichnet.
